package com.adiuvo.aigun_02;

public class DateEntry
{

}

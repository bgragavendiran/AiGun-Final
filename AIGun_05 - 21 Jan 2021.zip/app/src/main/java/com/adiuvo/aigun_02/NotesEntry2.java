package com.adiuvo.aigun_02;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.AsyncTask;
import android.content.Intent;

import java.nio.file.Files;
import java.util.Properties;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.ChannelExec;
import java.util.UUID;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.widget.Spinner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import android.widget.LinearLayout;
import android.view.View;
import java.util.Date;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import org.apache.commons.io.IOUtils;

import java.net.URLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;
import android.webkit.URLUtil;


import java.io.*;
import java.net.*;
import java.util.*;



public class NotesEntry2 extends AppCompatActivity{
    final static String path_name= Environment.getExternalStorageDirectory() + "/AIGun_05";
    //final static String path_name= Environment.getExternalStorageDirectory() + "/AIGun_03" + Cowname1;

    Button submit1;
    EditText nF;
    String Cowname1;
    String Farmname1;
    ImageButton goNextButton;
    TextView textView;
    String src;
    String src1;
    String dst;



    private static final SparseIntArray ORIENTATIONS = new SparseIntArray();

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 90);
        ORIENTATIONS.append(Surface.ROTATION_90, 0);
        ORIENTATIONS.append(Surface.ROTATION_180, 270);
        ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notes_entry_2);
        Intent intent = getIntent();
        Cowname1 = intent.getStringExtra("cowname");
        Farmname1 = intent.getStringExtra("farmname");
        nF = (EditText) findViewById(R.id.nF);
        submit1 = (Button) findViewById(R.id.submitButton);


        String src = Environment.getExternalStorageDirectory().getPath()
                + "/Depstech/Video";
        String src1 = Environment.getExternalStorageDirectory().getPath()
                + "/Depstech/Picture";
        String dst = Environment.getExternalStorageDirectory().getPath()
                + "/AIGun_05";

        goNextButton = findViewById(R.id.goNextbutton);
        goNextButton.setOnClickListener(new View.OnClickListener() {
             @Override
            public void onClick(View v) {
                 prepareDepstechDirectories();
                 launchDepstech();
            }
        });

       // textView = findViewById(R.id.goNextTextview);
        //textView.setOnClickListener(new View.OnClickListener() {
          //  @Override
          //  public void onClick(View v) {

                try {
                    copy(src, dst);
                    copy1(src1, dst);
                     } catch (IOException e) {
                    e.printStackTrace();
                }
           //  }
        //});


        final Spinner dropdown1 = findViewById(R.id.spinner2);
        String[] items1 = new String[]{"Positive","Negative"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items1);
        dropdown1.setAdapter(adapter1);

        submit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (saveFile(Farmname1, Cowname1,"Pregnancy Diagnosis :  " + dropdown1.getSelectedItem().toString()+ " \n" + "Notes and Feedbacks :  " + nF.getText().toString() + " \n"
                       )) {
                    Toast.makeText(NotesEntry2.this, "Saved to file", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(NotesEntry2.this,"Error save file!!!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void prepareDepstechDirectories() {
        File depthstechRootDir = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Video");
        File depthstechRootDir1 = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Picture");
        try {
            deleteAllDirectories(depthstechRootDir);
            deleteAllDirectories1(depthstechRootDir1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        createNewDepstechDirectory();
    }

    /**
     * Creates necessary depstech dir with sub dir
     */
    private void createNewDepstechDirectory() {
        File depthstechRootDir = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Video");
        File depthstechRootDir1 = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Picture");
        if(!depthstechRootDir.exists()){
            depthstechRootDir.mkdirs();
        }
        if(!depthstechRootDir1.exists()){
            depthstechRootDir1.mkdirs();
        }
    }

    /**
     *
     */
    private void launchDepstech() {
        Intent intent = new Intent();
        intent.setClassName("com.ipotensic.depstech", "com.logan.idepstech.CameraActivity");
        if(getPackageManager().resolveActivity(intent, 0) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "No app installed that can perform this action", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Deletes all sub dir with dir
     * @param f
     * @throws IOException
     */
    private void deleteAllDirectories(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles())
                c.delete();
        }
        f.delete();
        if (!f.delete())
            throw new FileNotFoundException("Failed to delete file: " + f);
    }

    private void deleteAllDirectories1(File f) throws IOException {
        if (f.isDirectory()) {
            for (File c : f.listFiles())
                c.delete();
        }
        f.delete();
        if (!f.delete())
            throw new FileNotFoundException("Failed to delete file: " + f);
    }

    public static void copy(String src, String dst) throws IOException {
        InputStream in = new FileInputStream(src);
        try {
            OutputStream out = new FileOutputStream(dst);
            try {
                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }

    public static void copy1(String src1, String dst) throws IOException {
        InputStream in = new FileInputStream(src1);
        try {
            OutputStream out = new FileOutputStream(dst);
            try {
                // Transfer bytes from in to out
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
            } finally {
                out.close();
            }
        } finally {
            in.close();
        }
    }



    public boolean saveFile(String Farmname1, String Cowname1,String data){
        int num = 0;
        Calendar c = Calendar.getInstance();
        System.out.println("Current time = &gt; " + c.getTime());
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String Date = df.format(c.getTime());

        String txtfilename = Cowname1 +"_Form3-PD_" + Date + ".txt";
        try {
            File storeDirectory_1 = new File(path_name,Farmname1);
            File storeDirectory1 = new File(storeDirectory_1, Cowname1);
            if (!storeDirectory1.exists()) {
                storeDirectory1.mkdirs();
            }

            File[] files = storeDirectory1.listFiles();

            if (files != null)
            {
                System.out.println("Files.length" +files.length);
                FileOutputStream fileOutputStream = new FileOutputStream(new File(storeDirectory1, (files.length + "."+ txtfilename)));
                fileOutputStream.write((data + System.getProperty("line.separator")).getBytes());
            }

            return true;
        }  catch(FileNotFoundException ex) {
            Log.d("saveToFile", ex.getMessage());
        }  catch(IOException ex) {
            Log.d("saveToFile", ex.getMessage());
        }
        return  false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        moveDataFromDepstechToAIGun();
    }

    /**
     * Copies and renames data from Depstech folder to AI Gun folder
     * Files are renamed based on cow name
     * Depstech folder is deleted post the above operations
     */
    private void moveDataFromDepstechToAIGun() {
        File aiGunRootDir = new File(Environment.getExternalStorageDirectory() + File.separator + "AIGUN_05" + File.separator + Cowname1);
        File depthstechRootDir = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Video");
        File depthstechRootDir1 = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech" + File.separator + "Picture");

        if(!aiGunRootDir.exists()){
            aiGunRootDir.mkdirs();
        }
        if(depthstechRootDir.exists()){
            File[] files = depthstechRootDir.listFiles();
            for(File f : files){
                File destFile =new File(aiGunRootDir + File.separator + Cowname1  +"_" + f.getName());
                try {
                    copy(f.getAbsolutePath(), destFile.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                deleteAllDirectories(depthstechRootDir);
            } catch (IOException e) {
                e.printStackTrace();
            }

            File depthstechRoot = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech");
            depthstechRoot.delete();
        }
        if(depthstechRootDir1.exists()){
            File[] files = depthstechRootDir1.listFiles();
            for(File f : files){
                File destFile =new File(aiGunRootDir + File.separator + Cowname1  +"_" + f.getName());
                try {
                    copy(f.getAbsolutePath(), destFile.getAbsolutePath());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                deleteAllDirectories(depthstechRootDir1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            File depthstechRoot = new File(Environment.getExternalStorageDirectory() + File.separator + "Depstech");
            depthstechRoot.delete();
       }
    }
}







